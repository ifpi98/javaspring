package hello.core.scan.filter;

@MyIncludeComponent
public class BeanA {
}
