package hello.core.member;
//회원 도메인 개발 – 회원 등급
public enum Grade {
    BASIC,
    VIP
}
//Enum이라는 것은 Enumeration의 앞글자로 열거형이라는 뜻을 가지고 있으며 서로 연관되거나 또는 관련이 있는 상수들의 집합을 의미합니다.
